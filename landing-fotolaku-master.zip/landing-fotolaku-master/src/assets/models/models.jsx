import Jose1 from "./Jose1.webp";
import Jose2 from './Jose2.webp'
import Jose3 from './Jose3.webp'
import Jose4 from './Jose4.webp'

import Dio1 from './Dio1.webp'
import Dio2 from './Dio2.webp'
import Dio3 from './Dio3.webp'
import Dio4 from './Dio4.webp'

import Jessica1 from './Jessica1.webp'
import Jessica2 from './Jessica2.webp'
import Jessica3 from './Jessica3.webp'
import Jessica4 from './Jessica4.webp'

import Edward1 from './Edward1.webp'
import Edward2 from './Edward2.webp'
import Edward3 from './Edward3.webp'
import Edward4 from './Edward4.webp'

import Connie1 from './Connie1.webp'
import Connie2 from './Connie2.webp'
import Connie3 from './Connie3.webp'
import Connie4 from './Connie4.webp'

import Jennifer1 from './Jennifer1.webp'
import Jennifer2 from './Jennifer2.webp'
import Jennifer3 from './Jennifer3.webp'
import Jennifer4 from './Jennifer4.webp'

import Nathan1 from './Nathan1.webp'
import Nathan2 from './Nathan2.webp'
import Nathan3 from './Nathan3.webp'
import Nathan4 from './Nathan4.webp'

import Jordan1 from './Jordan1.webp'
import Jordan2 from './Jordan2.webp'
import Jordan3 from './Jordan3.webp'
import Jordan4 from './Jordan4.webp'

import Kevin1 from './Kevin1.webp'
import Kevin2 from './Kevin2.webp'
import Kevin3 from './Kevin3.webp'
import Kevin4 from './Kevin4.webp'

import Nada1 from './Nada1.webp'
import Nada2 from './Nada2.webp'
import Nada3 from './Nada3.webp'
import Nada4 from './Nada4.webp'

import Steven1 from './Steven1.webp'
import Steven2 from './Steven2.webp'
import Steven3 from './Steven3.webp'
import Steven4 from './Steven4.webp'

import Wardah1 from './Wardah1.webp'
import Wardah2 from './Wardah2.webp'
import Wardah3 from './Wardah3.webp'
import Wardah4 from './Wardah4.webp'

export {
    Wardah1,
    Wardah2,
    Wardah3,
    Wardah4,
    Steven1,
    Steven2,
    Steven3,
    Steven4,
    Nada1,
    Nada2,
    Nada3,
    Nada4,
    Kevin1,
    Kevin2,
    Kevin3,
    Kevin4,
    Jordan1,
    Jordan2,
    Jordan3,
    Jordan4,
    Nathan1,
    Nathan2,
    Nathan3,
    Nathan4,
    Jennifer1,
    Jennifer2,
    Jennifer3,
    Jennifer4,
    Connie1,
    Connie2,
    Connie3,
    Connie4,
    Edward1,
    Edward2,
    Edward3,
    Edward4,
    Jose1,
    Jose2,
    Jose3,
    Jose4,
    Dio1,
    Dio2,
    Dio3,
    Dio4,
    Jessica1,
    Jessica2,
    Jessica3,
    Jessica4
}