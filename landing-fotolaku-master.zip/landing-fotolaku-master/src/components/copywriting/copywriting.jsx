import React from "react";

function Copywriting() {
  return (
    <section className="bg-[#FD8703] text-white text-center text-xl py-[3.265rem] px-2">
      <p>
        <q>
          FOTOLAKU HADIR MEMBANTU KAMU MEWUJUDKAN IMPIAN MENINGKATKAN
          BRANDINGMU
        </q>
      </p>
    </section>
  );
}

export default Copywriting;
